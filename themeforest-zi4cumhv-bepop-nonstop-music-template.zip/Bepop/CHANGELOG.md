v.1.0.2

* Add play playlist function in plryist.js
* Fixed .btn-outline-light class issue

v.1.0.1

* Update Bootstrap to 4.3.1
* Fix fullscreen
